//
//  FindOutAppApp.swift
//  FindOutApp
//
//  Created by cmStudent on 2024/09/30.
//

import SwiftUI

@main
struct FindOutAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
